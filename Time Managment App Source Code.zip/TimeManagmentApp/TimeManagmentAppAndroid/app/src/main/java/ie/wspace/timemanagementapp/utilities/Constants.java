package ie.wspace.timemanagementapp.utilities;

/*
 * Constants
 * Application Constants
 */
public class Constants {
    public static final String NOTE_ID_KEY = "note_id_key";
    public static final String  EDITING_KEY = "editing_key";
}
